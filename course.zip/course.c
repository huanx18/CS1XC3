/**
 * @file course.c
 * @author Xin Huang (huanx18@mcmaster.ca)
 * @brief There are four functions in this file: enroll_student, print_course, top_student,passing.
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include "course.h"
#include <stdlib.h>
#include <stdio.h>
/**
 * @brief This function is used to count students
 * 
 * @param course course pointer
 * @param student student pointer
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}
/**
 * @brief This function is used to print student data
 * 
 * @param course course pointer
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}
/**
 * @brief This function is used to select the students with the highest grade point averages
 * @brief It is a for loop that allows the average score of the previous student to be compared with the average score of the next student, with the highest average score being recorded. And so on, if a better average score is encountered, the previous highest average score data is refreshed.
 * @param course course pointer
 * @return Student* student
 */
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}
/**
 * @brief This function is used to count students with an average score above 50
 * @brief There are two for loops in total, the first loop adds 1 to the count if a student's average score is over or equal to 50, thus calculating the number of students who are passing. The second loop is the length of the total number of students in memory, by for looping if the average score is over 50 or equal to 50, the student is recorded in memory.
 * @param course course pointer
 * @param total_passing total_passing pointer
 * @return Student* passing
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  passing = calloc(count, sizeof(Student));

  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}