/**
 * @file student.h
 * @author Xin Huang (huanx18@mcmaster.ca)
 * @brief Create new type about student
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */

/**
 * @brief A new type called student has been defined
 * @brief input is first_name, last_name, id, grades pointer, num_grades.
 */
typedef struct _student 
{ 
  /// char type of student first name , where the number of elements is 50.
  char first_name[50];
  /// char type of student last name , where the number of elements is 50.
  char last_name[50];
  /// char type of student id , where the number of elements is 11.
  char id[11];
  /// double type of grades pointer.
  double *grades;
  /// int type of number of grades.
  int num_grades; 
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
