/**
 * @file course.h
 * @author Xin Huang (huanx18@mcmaster.ca)
 * @brief Create new type about course
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include "student.h"
#include <stdbool.h>
/**
 * @brief A new type is defined, called course
 * @brief input is name, code, students pointer, total_students.
 */
typedef struct _course 
{
  /// char type of name , where the number of elements is 100.
  char name[100];
  /// char type of code , where the number of elements is 10.
  char code[10];
  /// student type of student pointer
  Student *students;
  /// int type of total number of students
  int total_students;
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


