var searchData=
[
  ['last_5fname_0',['last_name',['../struct__student.html#a48ed726bdb658f3f3e16a5ab1cd0f87a',1,'_student']]]
];
